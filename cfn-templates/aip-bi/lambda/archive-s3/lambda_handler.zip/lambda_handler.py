from __future__ import print_function


import json
import boto3
import time
import datetime
import json
import boto3
import string
from botocore.client import ClientError

s3 = boto3.resource('s3')
s3c = boto3.client('s3')

def lambda_handler(event, context):
    message = event['Records'][0]['Sns']['Message']
    parsed_message = json.loads(message)
    source_bucket = parsed_message['Records'][0]['s3']['bucket']['name'] 
    print ("BUCKET :" + source_bucket)
    key = parsed_message['Records'][0]['s3']['object']['key']
    print ("KEY :" + key)
    region = parsed_message['Records'][0]['awsRegion']
    print ("AWSREGION :" + region)
    src_bucket_instance = s3.Bucket(source_bucket)
    copy_src = source_bucket + '/' + key
    print ("COPYSRC :" + copy_src)
    archival_bucket = 'aip-s3-archive-'+region+'-661072482170'
    #########################################################
    for i in src_bucket_instance.objects.all():
            #Getting the current datetime stamp 
            now = datetime.datetime.now()
            now_for_date_diff = str('%02d' % now.year) + '-' + str('%02d' % now.month) + '-' + str(now.day) + ' ' + str(now.hour) + ':' + str(now.minute)+ ':' + str(now.second)
            
            #Getting the current keys lastmodified date and croping it for python date difference function
            last_modified = str(i.last_modified)
            last_modified = last_modified[:19]
            
            #Converting the current date and last modified date to python formats for checking the difference
            t1 = datetime.datetime.strptime(now_for_date_diff, "%Y-%m-%d %H:%M:%S")
            t2 = datetime.datetime.strptime(last_modified, "%Y-%m-%d %H:%M:%S")
            
            #Checking the date difference
            difference = t1-t2
            
            copy_src = source_bucket + '/' + i.key
            diff = int(difference.days)
            if diff >= 0 :
                #new_backup_bucket_name = source_bucket + '/' + str('%02d' % now.year) + '/' + str('%02d' % now.month) + '/' + str(now.day) + '/'
                key_last_modified_datetimestamp = datetime.datetime.strptime(last_modified, "%Y-%m-%d %H:%M:%S")
                new_backup_bucket_name = source_bucket + '/' + str('%02d' % key_last_modified_datetimestamp.year) + '/' + str('%02d' % key_last_modified_datetimestamp.month) + '/' + str(key_last_modified_datetimestamp.day) + '/'
                new_key_name = new_backup_bucket_name + i.key
                s3.Object(archival_bucket, new_key_name).copy_from(CopySource=copy_src,ServerSideEncryption='AES256',)
                print('ARCHIVED :' + copy_src)
   # print("BUCKET SNS: " + bucket)
    #archival_bucket = 'aip-s3-archive-us-east-1-661072482170'
    #source_bucket = 'bi-etl-devops-s3-sse-test'
    #src_bucket_instance = s3.Bucket(source_bucket)
    #key = 'index.js'
    #copy_src = 'bi-etl-devops-s3-sse-test/' + key
    #s3.Object(archival_bucket, key).copy_from(CopySource=copy_src)
    return source_bucket